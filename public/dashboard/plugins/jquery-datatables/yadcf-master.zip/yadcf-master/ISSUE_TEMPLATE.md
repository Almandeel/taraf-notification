**Please provide a test page with the issue / test page with working example - for new feature**


Question should be asked on stackoverflow and tagged with yadcf - http://stackoverflow.com/questions/tagged/yadcf , that way more people
will be able to help you and your questions will be easier to find for others

Use github for bug reports or new features request only

In case of bug always post a code sample that resembles your issue or even better provide a link to your page

**Please provide a test page with the issue / test page with working example - for new feature**
